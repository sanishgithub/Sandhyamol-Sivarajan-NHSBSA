package stepDefinitions;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import baseClass.BaseClass;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import pages.NHSCostPayHelpPage;
import pages.QuestionsPage;
import pages.ResultPage;

public class Steps extends BaseClass {

	@Before
	public void setUp() {
		if (browser.equals("Chrome")) {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
		}
		if (browser.equals("Firefox")) {
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
		}
		
		driver.manage().window().maximize();
		
	}
	
	@After
	public void closeBrowser() {
		driver.quit();
		
	}
	
	@Given("user launches checker tool")
	public void userLaunchesCheckerTool() {
		driver.get(baseURL);
		nhsCostPayHelpPage = new NHSCostPayHelpPage(driver);
		qstnpage = new QuestionsPage(driver);
		resultPage = new ResultPage(driver);
	}

	@Given("I am a person from Wales")
	public void i_am_a_person_from_wales() {
		nhsCostPayHelpPage.acceptCookies();
		nhsCostPayHelpPage.clickStartButton();
		qstnpage.clickWalesRadioButton();
		qstnpage.clicknextButton();
	}

	@When("I put my circumstances into the Checker tool {string} {string} {string}")
	public void i_put_my_circumstances_into_the_checker_tool(String day, String month, String year) {
		qstnpage.clickYesRadioButton();
		qstnpage.clicknextButton();
		qstnpage.clickWalesRadioButton();
		qstnpage.clicknextButton();
		qstnpage.enterDOB(day, month, year);
		qstnpage.clicknextButton();
		qstnpage.clickNoRadioButton();
		qstnpage.clicknextButton();
		qstnpage.clickNoRadioButton();
		qstnpage.clicknextButton();
		qstnpage.clickNoRadioButton();
		qstnpage.clicknextButton();
		qstnpage.clickNoRadioButton();
		qstnpage.clicknextButton();
		qstnpage.clickNoRadioButton();
		qstnpage.clicknextButton();
		qstnpage.clickNoRadioButton();
		qstnpage.clicknextButton();
		qstnpage.clickNoRadioButton();
		qstnpage.clicknextButton();
		qstnpage.clickNoRadioButton();
		qstnpage.clicknextButton();
	}

	@Then("I should get a result of whether I will get help or not")
	public void i_should_get_a_result_of_whether_i_will_get_help_or_not() {
		resultPage.verifyPersonGetHelpOrNot();
	}
	


}
