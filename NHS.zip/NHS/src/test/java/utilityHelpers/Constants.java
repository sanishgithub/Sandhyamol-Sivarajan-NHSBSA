package utilityHelpers;

public class Constants {
	
	public static String getHelpMsg_ResultPg = "You get help with NHS costs";

}
