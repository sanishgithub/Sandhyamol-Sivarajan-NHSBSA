package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class QuestionsPage {
	
	public WebDriver driver;
	
	public QuestionsPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(this.driver, this);
	}
	
	
	@FindBy(xpath = "//input[@id='radio-wales']")
	public WebElement WalesRdb;
	@FindBy(id = "next-button")
	public WebElement nextBtn;
	@FindBy(id = "radio-yes")
	public WebElement yesRdb;
	@FindBy(id = "radio-no")
	public WebElement noRdb;
	@FindBy(id = "dob-day")
	public WebElement dayDOB;
	@FindBy(id = "dob-month")
	public WebElement monthDOB;
	@FindBy(id = "dob-year")
	public WebElement yearDOB;
	
	public void clickWalesRadioButton() {
		WalesRdb.click();
	}
	
	public void clicknextButton() {
		nextBtn.click();
	}
	
	public void clickYesRadioButton() {
		yesRdb.click();
	}
	public void clickNoRadioButton() {
		noRdb.click();
	}
	
	public void enterDOB(String day, String month, String year) {
		dayDOB.sendKeys(day);
		monthDOB.sendKeys(month);
		yearDOB.sendKeys(year);
	}

}
