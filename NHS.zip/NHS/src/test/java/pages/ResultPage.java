package pages;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utilityHelpers.Constants;


public class ResultPage {
	
	public WebDriver driver;
	
	public ResultPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(this.driver, this);
	}
	
	
	@FindBy(xpath = "//h1[@id='result-heading']")
	public WebElement resultTxt;

	
	public void verifyPersonGetHelpOrNot() {
		boolean condition = resultTxt.getText().contains(Constants.getHelpMsg_ResultPg);
		Assert.assertTrue("Help message is not showing as expected in result page", condition);
	}
	


}
