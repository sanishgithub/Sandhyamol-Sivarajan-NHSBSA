package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class NHSCostPayHelpPage {
	
	public WebDriver driver;
	
	public NHSCostPayHelpPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(this.driver, this);
	}
	
	
	@FindBy(id = "nhsuk-cookie-banner__link_accept_analytics")
	public WebElement acceptCookiesBtn;
	@FindBy(id = "next-button")
	public WebElement startBtn;
	
	
	public void acceptCookies() {
		acceptCookiesBtn.click();
	}
	public void clickStartButton() {
		startBtn.click();
	}

}
