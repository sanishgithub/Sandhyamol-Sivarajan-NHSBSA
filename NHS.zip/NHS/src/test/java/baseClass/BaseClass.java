package baseClass;

import org.openqa.selenium.WebDriver;

import pages.NHSCostPayHelpPage;
import pages.QuestionsPage;
import pages.ResultPage;

public class BaseClass {
	
	public WebDriver driver;
	public NHSCostPayHelpPage nhsCostPayHelpPage;
	public QuestionsPage qstnpage;
	public ResultPage resultPage;
	public String browser = "Chrome";
	public String baseURL = "https://services.nhsbsa.nhs.uk/check-for-help-paying-nhs-costs/start";
}
